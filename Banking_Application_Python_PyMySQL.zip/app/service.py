import random
from decimal import Decimal, InvalidOperation

from .models import Account
from .repository import BankingRepository
from .utils import hash_pin, validate_email, validate_pin


class BankingService:
    """Business logic layer."""

    def __init__(self):
        self.repo = BankingRepository()

    def generate_account_number(self):
        while True:
            number = str(random.randint(1000000000, 9999999999))
            if not self.repo.get_account(number):
                return number

    def create_account(self, full_name, email, phone, address, pin):
        if not full_name.strip():
            raise ValueError("Name is required.")

        if not validate_email(email):
            raise ValueError("Invalid email address.")

        if not phone.strip():
            raise ValueError("Phone number is required.")

        if not validate_pin(pin):
            raise ValueError("PIN must contain exactly 4 digits.")

        account_number = self.generate_account_number()

        account = Account(
            account_number=account_number,
            full_name=full_name.strip(),
            email=email.strip(),
            phone=phone.strip(),
            address=address.strip(),
            pin_hash=hash_pin(pin)
        )

        self.repo.create_account(account)
        return account_number

    def login(self, account_number, pin):
        if not validate_pin(pin):
            raise ValueError("PIN must contain exactly 4 digits.")

        return self.repo.verify_login(account_number, hash_pin(pin))

    def update_profile(self, account_number, full_name, email, phone, address):
        if not validate_email(email):
            raise ValueError("Invalid email address.")

        return self.repo.update_account(
            account_number,
            full_name.strip(),
            email.strip(),
            phone.strip(),
            address.strip()
        )

    def deposit(self, account_number, amount):
        try:
            amount = Decimal(str(amount))
        except InvalidOperation:
            raise ValueError("Invalid amount.")

        return self.repo.deposit(account_number, amount)

    def withdraw(self, account_number, amount):
        try:
            amount = Decimal(str(amount))
        except InvalidOperation:
            raise ValueError("Invalid amount.")

        return self.repo.withdraw(account_number, amount)
