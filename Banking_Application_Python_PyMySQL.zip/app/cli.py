from .service import BankingService
from .utils import money, pause, print_account


class BankingCLI:
    def __init__(self):
        self.service = BankingService()

    def run(self):
        while True:
            self.clear_screen()
            print("==========================================")
            print("       PYTHON BANKING APPLICATION")
            print("==========================================")
            print("1. Create Account")
            print("2. Login")
            print("3. Exit")

            choice = input("\nEnter choice: ").strip()

            if choice == "1":
                self.create_account()
            elif choice == "2":
                self.login()
            elif choice == "3":
                print("\nThank you for using the Banking Application.")
                break
            else:
                print("\nInvalid choice.")
                pause()

    def create_account(self):
        print("\n========== CREATE ACCOUNT ==========")

        name = input("Full Name: ")
        email = input("Email: ")
        phone = input("Phone: ")
        address = input("Address: ")
        pin = input("Create 4-digit PIN: ")

        try:
            account_number = self.service.create_account(
                name, email, phone, address, pin
            )
            print("\nAccount created successfully!")
            print(f"Your Account Number: {account_number}")
        except Exception as e:
            print(f"\nError: {e}")

        pause()

    def login(self):
        print("\n========== LOGIN ==========")
        account_number = input("Account Number: ")
        pin = input("PIN: ")

        try:
            account = self.service.login(account_number, pin)
            if not account:
                print("\nInvalid account number or PIN.")
                pause()
                return

            self.account_menu(account["account_number"])
        except Exception as e:
            print(f"\nError: {e}")
            pause()

    def account_menu(self, account_number):
        while True:
            account = self.service.repo.get_account(account_number)

            if not account:
                print("\nAccount no longer exists.")
                pause()
                return

            self.clear_screen()
            print("==========================================")
            print(f"       WELCOME, {account['full_name']}")
            print("==========================================")
            print(f"Current Balance: {money(account['balance'])}")
            print("------------------------------------------")
            print("1. Check Account Information")
            print("2. Deposit")
            print("3. Withdraw")
            print("4. Update Account Information")
            print("5. Transaction History")
            print("6. Delete Account")
            print("7. Logout")

            choice = input("\nEnter choice: ").strip()

            if choice == "1":
                print_account(account)
                pause()
            elif choice == "2":
                self.deposit(account_number)
            elif choice == "3":
                self.withdraw(account_number)
            elif choice == "4":
                self.update(account_number)
            elif choice == "5":
                self.history(account_number)
            elif choice == "6":
                if self.delete(account_number):
                    return
            elif choice == "7":
                return
            else:
                print("\nInvalid choice.")
                pause()

    def deposit(self, account_number):
        amount = input("\nEnter deposit amount: ")

        try:
            new_balance = self.service.deposit(account_number, amount)
            print(f"\nDeposit successful.")
            print(f"New Balance: {money(new_balance)}")
        except Exception as e:
            print(f"\nError: {e}")

        pause()

    def withdraw(self, account_number):
        amount = input("\nEnter withdrawal amount: ")

        try:
            new_balance = self.service.withdraw(account_number, amount)
            print(f"\nWithdrawal successful.")
            print(f"New Balance: {money(new_balance)}")
        except Exception as e:
            print(f"\nError: {e}")

        pause()

    def update(self, account_number):
        account = self.service.repo.get_account(account_number)

        print("\n========== UPDATE ACCOUNT ==========")
        name = input(f"Full Name [{account['full_name']}]: ") or account["full_name"]
        email = input(f"Email [{account['email']}]: ") or account["email"]
        phone = input(f"Phone [{account['phone']}]: ") or account["phone"]
        address = input(
            f"Address [{account.get('address') or ''}]: "
        ) or (account.get("address") or "")

        try:
            self.service.update_profile(
                account_number, name, email, phone, address
            )
            print("\nAccount updated successfully.")
        except Exception as e:
            print(f"\nError: {e}")

        pause()

    def history(self, account_number):
        rows = self.service.repo.transaction_history(account_number)

        print("\n========== TRANSACTION HISTORY ==========")

        if not rows:
            print("No transactions found.")
        else:
            for row in rows:
                print(
                    f"{row['created_at']} | "
                    f"{row['transaction_type']:<12} | "
                    f"{money(row['amount']):>12} | "
                    f"Balance: {money(row['balance_after'])} | "
                    f"{row['description']}"
                )

        pause()

    def delete(self, account_number):
        confirm = input(
            "\nType DELETE to permanently delete this account: "
        )

        if confirm != "DELETE":
            print("Deletion cancelled.")
            pause()
            return False

        try:
            affected = self.service.repo.delete_account(account_number)

            if affected:
                print("\nAccount deleted successfully.")
            else:
                print("\nAccount not found.")

        except Exception as e:
            print(f"\nError: {e}")

        pause()
        return True

    @staticmethod
    def clear_screen():
        print("\n" * 2)
