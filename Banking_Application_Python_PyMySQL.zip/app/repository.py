from decimal import Decimal
from .database import Database


class BankingRepository:

    def create_account(self, account):
        conn = Database.get_connection()
        try:
            with conn.cursor() as cur:
                sql = """
                    INSERT INTO accounts
                    (account_number, full_name, email, phone, address, pin_hash)
                    VALUES (%s, %s, %s, %s, %s, %s)
                """
                cur.execute(sql, (
                    account.account_number,
                    account.full_name,
                    account.email,
                    account.phone,
                    account.address,
                    account.pin_hash
                ))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def get_account(self, account_number):
        conn = Database.get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT * FROM accounts WHERE account_number = %s",
                    (account_number,)
                )
                return cur.fetchone()
        finally:
            conn.close()

    def get_account_by_id(self, account_id):
        conn = Database.get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT * FROM accounts WHERE account_id = %s",
                    (account_id,)
                )
                return cur.fetchone()
        finally:
            conn.close()

    def verify_login(self, account_number, pin_hash):
        conn = Database.get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT * FROM accounts
                    WHERE account_number = %s AND pin_hash = %s
                    """,
                    (account_number, pin_hash)
                )
                return cur.fetchone()
        finally:
            conn.close()

    def update_account(self, account_number, full_name, email, phone, address):
        conn = Database.get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE accounts
                    SET full_name=%s, email=%s, phone=%s, address=%s
                    WHERE account_number=%s
                    """,
                    (full_name, email, phone, address, account_number)
                )
                affected = cur.rowcount
            conn.commit()
            return affected
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def delete_account(self, account_number):
        conn = Database.get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "DELETE FROM accounts WHERE account_number=%s",
                    (account_number,)
                )
                affected = cur.rowcount
            conn.commit()
            return affected
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def deposit(self, account_number, amount, description="Cash deposit"):
        if amount <= 0:
            raise ValueError("Amount must be greater than zero.")

        conn = Database.get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT account_id, balance
                    FROM accounts
                    WHERE account_number=%s
                    FOR UPDATE
                    """,
                    (account_number,)
                )
                account = cur.fetchone()

                if not account:
                    raise ValueError("Account not found.")

                new_balance = Decimal(account["balance"]) + Decimal(str(amount))

                cur.execute(
                    """
                    UPDATE accounts
                    SET balance=%s
                    WHERE account_number=%s
                    """,
                    (new_balance, account_number)
                )

                cur.execute(
                    """
                    INSERT INTO transactions
                    (account_id, transaction_type, amount, balance_after, description)
                    VALUES (%s, 'DEPOSIT', %s, %s, %s)
                    """,
                    (
                        account["account_id"],
                        amount,
                        new_balance,
                        description
                    )
                )

            conn.commit()
            return new_balance
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def withdraw(self, account_number, amount, description="Cash withdrawal"):
        if amount <= 0:
            raise ValueError("Amount must be greater than zero.")

        conn = Database.get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT account_id, balance
                    FROM accounts
                    WHERE account_number=%s
                    FOR UPDATE
                    """,
                    (account_number,)
                )
                account = cur.fetchone()

                if not account:
                    raise ValueError("Account not found.")

                current_balance = Decimal(account["balance"])
                amount = Decimal(str(amount))

                if amount > current_balance:
                    raise ValueError("Insufficient balance.")

                new_balance = current_balance - amount

                cur.execute(
                    """
                    UPDATE accounts
                    SET balance=%s
                    WHERE account_number=%s
                    """,
                    (new_balance, account_number)
                )

                cur.execute(
                    """
                    INSERT INTO transactions
                    (account_id, transaction_type, amount, balance_after, description)
                    VALUES (%s, 'WITHDRAW', %s, %s, %s)
                    """,
                    (
                        account["account_id"],
                        amount,
                        new_balance,
                        description
                    )
                )

            conn.commit()
            return new_balance
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def transaction_history(self, account_number):
        conn = Database.get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT t.*
                    FROM transactions t
                    JOIN accounts a ON a.account_id=t.account_id
                    WHERE a.account_number=%s
                    ORDER BY t.created_at DESC
                    """,
                    (account_number,)
                )
                return cur.fetchall()
        finally:
            conn.close()
