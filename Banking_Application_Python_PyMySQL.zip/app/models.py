from dataclasses import dataclass
from decimal import Decimal


@dataclass
class Account:
    account_number: str
    full_name: str
    email: str
    phone: str
    address: str
    pin_hash: str
    balance: Decimal = Decimal("0.00")
