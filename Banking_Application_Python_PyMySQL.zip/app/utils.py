import hashlib
import re


def hash_pin(pin: str) -> str:
    return hashlib.sha256(pin.encode("utf-8")).hexdigest()


def validate_pin(pin: str) -> bool:
    return pin.isdigit() and len(pin) == 4


def validate_email(email: str) -> bool:
    pattern = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"
    return bool(re.match(pattern, email))


def money(value):
    return f"₹{float(value):,.2f}"


def pause():
    input("\nPress Enter to continue...")


def print_account(account):
    print("\n========== ACCOUNT INFORMATION ==========")
    print(f"Account Number : {account['account_number']}")
    print(f"Name           : {account['full_name']}")
    print(f"Email          : {account['email']}")
    print(f"Phone          : {account['phone']}")
    print(f"Address        : {account.get('address') or '-'}")
    print(f"Balance        : {money(account['balance'])}")
    print(f"Created At     : {account['created_at']}")
    print("=========================================")
