from app.cli import BankingCLI


if __name__ == "__main__":
    try:
        BankingCLI().run()
    except KeyboardInterrupt:
        print("\n\nApplication closed.")
    except Exception as e:
        print(f"\nApplication error: {e}")
