# Banking Application - Python + PyMySQL

A console-based banking application using:
- Python
- OOP
- Control statements
- PyMySQL
- MySQL
- CRUD operations
- Transactions

## Features
1. Account creation
2. Deposit
3. Withdrawal
4. Check account holder information
5. Update account holder information
6. Transaction history
7. Delete account
8. Login using account number + PIN

## Setup

### 1. Install dependency
```bash
pip install pymysql
```

### 2. Create the database
Open MySQL and run:
```sql
SOURCE database/schema.sql;
```

Or copy/paste the SQL from `database/schema.sql`.

### 3. Configure MySQL
Open `app/config.py` and change:
- MYSQL_HOST
- MYSQL_USER
- MYSQL_PASSWORD
- MYSQL_DB

### 4. Run
```bash
python main.py
```

## Default design
The application stores PINs as SHA-256 hashes rather than plain text.
For a production banking system, use a stronger password hashing algorithm such as Argon2/bcrypt, MFA, audit logging, encryption, and proper authorization controls.
